
class Info{
  String seed;
  int result;
  int page;
  String version;

  Info({this.seed,
    this.result,
    this.page,
    this.version,
  });

  factory Info.fromJson(Map<String,dynamic> json){
    return Info(
      seed: json['seed'],
      result: json['results'],
      page: json['page'],
      version: json['version'],
    );
  }





}