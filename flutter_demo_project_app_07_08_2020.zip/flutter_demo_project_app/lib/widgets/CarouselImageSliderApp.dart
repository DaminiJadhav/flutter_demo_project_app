

import 'package:flutter/material.dart';

class CarouselImageSliderApp extends StatefulWidget{
  @override
  _CarouselImageSliderAppState createState() => _CarouselImageSliderAppState();
}

class _CarouselImageSliderAppState extends State<CarouselImageSliderApp> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Custom Header'),
      ),
    );
    // TODO: implement build
    throw UnimplementedError();
  }
}