

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'ProductList.dart';

void main() => runApp(formapp());

class formapp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final appTitle = 'Flutter Form Demo';
    return MaterialApp(
      title: appTitle,
      home: Scaffold(
        appBar: AppBar(
          title: Text(appTitle),
        ),
        body: MyCustomForm(),
      ),
    );
  }
}

class MyCustomForm extends StatefulWidget {
  @override
  _State createState() => _State();
}

class _State extends State<MyCustomForm> {
 String selectedIndex;
  final formkey=GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formkey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          TextFormField(
            decoration: const InputDecoration(
              icon: const Icon(Icons.person),
              hintText: 'Enter full name',
              labelText: 'Name'
            ),
            validator: (value){
              if(value.isEmpty){
                return 'please enter name';
              }
              return null;
            },
          ),
          TextFormField(
            decoration: const InputDecoration(
              icon: const Icon(Icons.phone),
              hintText: 'Enter a phone number',
              labelText: 'Phone',
            ),
            validator: (value) {
              if (value.isEmpty) {
                return 'Please enter valid phone number';
              }
              return null;
            },
          ),
          TextFormField(
            decoration: const InputDecoration(
              icon: const Icon(Icons.calendar_today),
              hintText: 'Enter your date of birth',
              labelText: 'Dob',
            ),
            validator: (value) {
              if (value.isEmpty) {
                return 'Please enter valid date';
              }
              return null;
            },
          ),
          new Container(
            padding: const EdgeInsets.all(15.0),
            child: new RaisedButton(
              child: Text('Submit'),
                onPressed:(){
                  if(formkey.currentState.validate()){
                    Scaffold.of(context).showSnackBar(SnackBar(
                      content: Text('Data is in processing'),
                    ));

                    showAlertDialog(context);
                  }
                }),
          ),

//            DropdownButtonFormField(
//              hint: Text('Select item'),
//              value: selectedIndex,
//              onChanged: (pos){
//                setState(() {
//                  selectedIndex=pos;
//                });
//              },
//              items: ["C","C++","PHP","Java","Android","Flutter"].map((label) =>
//                    DropdownMenuItem(
//                      value: label,
//                      child: Text(label),
//                    )
//              ).toList(),
//            )


        ],
      ),
    );
  }
  showAlertDialog(BuildContext context){

    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    AlertDialog dialog=AlertDialog(
      title: Text('Simple Alert '),
      content: Text('This is an alert message.'),
//      actions:[okButton],

      actions: <Widget>[
        FlatButton(
          child: Text('ok'),
          onPressed: (){
//            Navigator.of(context).pop();
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>ProductList()));
//          SystemNavigator.pop();
          },
        )
      ],

    );

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return dialog;
      },
    );

  }
}

