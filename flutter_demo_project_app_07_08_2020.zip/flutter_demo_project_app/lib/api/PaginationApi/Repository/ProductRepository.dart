

import 'package:flutter/foundation.dart';
import 'package:flutterdemoprojectapp/api/PaginationApi/Repository/MovieRepository.dart';
import 'package:flutterdemoprojectapp/api/PaginationApi/movielist.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

const MOVIE_API_KEY = "e5c7041343c************8b720e80c7";    // Replace with your own API key
const BASE_URL = "https://api.themoviedb.org/3/movie/";

class MovieProdRepository implements MovieRepository{

  @override
  Future<MovieList> fetchMovie(int pagenumber) async{
    http.Response response = await http.get(BASE_URL +
        "popular?api_key=" +
        MOVIE_API_KEY +
        "&page=" +
        pagenumber.toString());

//    return compute(pa)

    // TODO: implement fetchMovie
    throw UnimplementedError();

  }

}

