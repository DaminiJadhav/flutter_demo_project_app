


import 'package:flutter/cupertino.dart';

import 'movie.dart';

class MovieList {
  MovieList({
    this.page,
    this.totalResults,
    this.totalPages,
    this.movies,
  });

  final int page;
  final int totalResults;
  final int totalPages;
  final List<Movie> movies;

  MovieList.fromMap(Map<String,dynamic> value)
    : page=value['page'],
      totalResults = value['total_results'],
      totalPages = value['total_pages'],
      movies=new List<Movie>.from(
          value['results'].map((movies) =>
              Movie.fromJson(
                  movies
              )
          )
      );




}
