

import 'package:flutterdemoprojectapp/api/PaginationApi/movielist.dart';

abstract class MovieRepository{

  Future<MovieList> fetchMovie(int pagenumber);

}