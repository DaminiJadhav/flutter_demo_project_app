import 'package:flutter/material.dart';
import 'package:flutterdemoprojectapp/api/HttpGetApi.dart';
import 'package:flutterdemoprojectapp/menu_items/menuItemApp_Icon.dart';
import 'package:flutterdemoprojectapp/pagination/StudentPaginationList.dart';
import 'package:flutterdemoprojectapp/shimmer/ShimmerApp.dart';
import 'package:flutterdemoprojectapp/shimmer/ShimmerListviewLayout.dart';
import 'package:flutterdemoprojectapp/widgets/BottomAppBarFloating.dart';
import 'package:flutterdemoprojectapp/widgets/CarouselImageSlider.dart';
import 'package:flutterdemoprojectapp/widgets/CheckAllPermission.dart';
import 'package:flutterdemoprojectapp/widgets/CheckPermissions.dart';
import 'package:flutterdemoprojectapp/widgets/CustomStickyHeader.dart';
import 'package:flutterdemoprojectapp/widgets/DateTimePickerApp.dart';
import 'package:flutterdemoprojectapp/widgets/DynamicLinkApp.dart';
import 'package:flutterdemoprojectapp/widgets/Expandable&StickyListApp.dart';
import 'package:flutterdemoprojectapp/widgets/FacebookAndroidLoginApp.dart';
import 'package:flutterdemoprojectapp/widgets/GoogleLoginApp.dart';
import 'package:flutterdemoprojectapp/widgets/ImagePickerApp.dart';
import 'package:flutterdemoprojectapp/widgets/LaunchUrlApp.dart';
import 'package:flutterdemoprojectapp/widgets/NotificationApp.dart';
import 'package:flutterdemoprojectapp/widgets/PaginationListViewData.dart';
import 'package:flutterdemoprojectapp/widgets/PaginationRestApi.dart';
import 'package:flutterdemoprojectapp/widgets/ProgressIndicatorApp.dart';
import 'package:flutterdemoprojectapp/widgets/ProgressIndicatorTimerApp.dart';
import 'package:flutterdemoprojectapp/widgets/SearchViewApp_Delegate.dart';
import 'package:flutterdemoprojectapp/widgets/SharedPreferenceLoadImage.dart';
import 'package:flutterdemoprojectapp/widgets/SharedPreferencesApp.dart';
import 'package:flutterdemoprojectapp/widgets/SilverAppBarExample.dart';
import 'package:flutterdemoprojectapp/widgets/SliverGridApp.dart';
import 'package:flutterdemoprojectapp/widgets/TabBarApp.dart';
import 'package:flutterdemoprojectapp/widgets/TabbedAppBarSample.dart';
import 'package:flutterdemoprojectapp/widgets/TableApp.dart';
import 'package:flutterdemoprojectapp/widgets/TablePaginatedApp.dart';
import 'package:flutterdemoprojectapp/widgets/TextFieldOutline.dart';
import 'package:flutterdemoprojectapp/widgets/VisibilityApp.dart';
import 'package:flutterdemoprojectapp/widgets/formapp.dart';
import 'api/HttpGetApiWithParameter.dart';
import 'api/HttpPostApi.dart';
import 'designs/DatingLoginApp.dart';
import 'dioApi/pagination/PaginationDioApi.dart';
import 'file:///D:/flutter/MyApp/flutter_demo_project_app/lib/menu_items/menuItemApp.dart';
import 'ios/CupertinoAlertDialogApp.dart';
import 'ios/CupertinoContextMenuApp.dart';
import 'ios/CupertinoDatapickerApp.dart';
import 'menu_items/menuItem_Divider&Check.dart';

void main() => runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: StudentPaginationList() ,
      theme: ThemeData(
          brightness: Brightness.light,
          primaryColor: Colors.lightBlue,
          primaryColorDark: Colors.grey,
//        accentColor: Colors.deepPurpleAccent,
//          primarySwatch: Colors.red,


//        fontFamily: "IndieFlower"
          textTheme: TextTheme(
            headline1: TextStyle(fontSize: 36.0,fontWeight: FontWeight.bold),
            headline6: TextStyle(fontSize: 20.0, fontStyle: FontStyle.italic),
          )
//        primaryIconTheme: IconThemeData(color: Colors.grey)

      ),
    )

);
