
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterdemoprojectapp/pagination/StudentControllerApi.dart';
import 'package:flutterdemoprojectapp/pagination/StudentDataResponse.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class StudentPaginationList extends StatefulWidget {

  @override
  _StudentPaginationListState createState() => _StudentPaginationListState();
}

class _StudentPaginationListState extends State<StudentPaginationList> {

  Future<StudentDataResponse> studentdata;


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    studentdata=fetchdata(1);
//    fetchdata(1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pagination'),
      ),
      body: Center(
        child: FutureBuilder<StudentDataResponse>(
          future: studentdata,
          builder: (context,response){
            if(response.hasData){
              return Column(
                children: <Widget>[
                  Text('response : ${response.data.result.toString()}'),

                ],
              );

            }else if(response.hasError){
              return Text("Error Occured");
            }

            return CircularProgressIndicator();

          },
        ),
      )
    );
  }

  Future<StudentDataResponse> fetchdata(int pagaenumber) async {

    var url="https://randomuser.me/api?page=1&results=20&seed=abc";
    final response=await http.get(url);
    print(url);
    print(response.body);

    if(response.statusCode==200){

      return StudentDataResponse.fromJson(json.decode(response.body));
    }else{
      throw Exception('Failed to load post');
    }
  }

//  void _getMoredata(int index) async{
//
//      var url="https://randomuser.me/api/?page="+index.toString()+"&results=20&seed=abc";
//
//      print(url);
//
//      final response=await http.get(url);
//      print(response.body);
//      List list=new List();
//      list.add(response.body);
//
//
//
//  }
}
