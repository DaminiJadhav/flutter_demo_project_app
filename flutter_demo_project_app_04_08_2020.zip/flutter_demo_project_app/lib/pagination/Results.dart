

class Results{
  String gender;
  name nam;
  location loc;
  String email;
  login log;
  dob db;
  registered reg;
  String phone;
  String cell;
  id i;
  picture pic;
  String nat;

  Results({this.gender,this.nam,this.loc,this.email,this.log,this.db,this.reg,this.phone,this.cell,this.i,this.pic,this.nat});

  factory Results.fromJson(Map<String,dynamic> json){
    return Results(
      gender: json['gender'],
      nam: name.fromJson(json['name']),
      loc: json['location'],
      email: json['email'],
      log: json['login'],
      db: json['dob'],
      reg: json['registered'],
      phone: json['phone'],
      cell: json['cell'],
      i: json['id'],
      pic: picture.fromJson(json['picture']),
      nat: json['nat'],


    );
  }



}




class name{
  String title;
  String first;
  String last;

  name({this.title,this.first,this.last});

  factory name.fromJson(Map<String,dynamic> json){
    return name(
      title: json['title'],
      first: json['first'],
      last: json['last'],
    );
  }

}

class location{

}
class login{

}
class dob{

}
class registered{

}
class id{

}
class picture{
  String large;
  String medium;
  String thumbnail;

  picture({this.large,this.medium,this.thumbnail});

  factory picture.fromJson(Map<String,dynamic> json){
    return picture(
      large: json['large'],
      medium: json['medium'],
      thumbnail: json['thumbnail'],
    );
  }
}

