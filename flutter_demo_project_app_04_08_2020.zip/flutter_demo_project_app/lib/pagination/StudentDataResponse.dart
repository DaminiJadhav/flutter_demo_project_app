
import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutterdemoprojectapp/pagination/Info.dart';
import 'package:flutterdemoprojectapp/pagination/Results.dart';


StudentDataResponse eventFromJson(String str) => StudentDataResponse.fromJson(json.decode(str));

//String eventToJson(StudentDataResponse data) => json.encode(data.toJson());


class StudentDataResponse{

  List<Results> result;
  Info info=new Info();

  StudentDataResponse({this.result,this.info});

  factory StudentDataResponse.fromJson(Map<String,dynamic> json){
    return StudentDataResponse(
      result: new List<Results>.from(
        json['results'].map((result)=>
        Results.fromJson(
          result
        ))
      ),
      info: Info.fromJson(json['info']),
    );
  }


//  Map<String,dynamic> toJson(){
////        "results":List<dynamic>.from(result.map((e) => e.toJson()));
//
//
//  };

//  StudentDataResponse.fromMap(Map<String,dynamic> value)
//     :result=new List<Results>.from(
//          value["results"].map((result)=>
//              Results.fromJson(
//                result
//              )
//          )
//  ),
//  info=Info.fromJson(value['info']);
}